package com.example.reto1maps.util;

public class Constans {

    public static String BASE_URL= "https://nuevo-proyecto-appmoviles-2020.firebaseio.com/";
}

